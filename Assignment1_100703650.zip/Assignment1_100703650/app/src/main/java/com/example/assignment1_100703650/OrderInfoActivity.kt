package com.example.assignment1_100703650

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text

class OrderInfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_info)

        val pizzaSelectionText: TextView = findViewById(R.id.pizzaSelection)
        val toppingSelectionText: TextView = findViewById(R.id.toppingSelection)
        val contactDetailsText: TextView = findViewById(R.id.contactDetails)
        val deliveryConfirmationText: TextView = findViewById(R.id.deliveryConfirmation)
        val backButton: Button = findViewById(R.id.backButton)

        val pizza: String? = intent.getStringExtra("pizza")
        val topping: String? = intent.getStringExtra("topping")
        val cheese: Boolean? = intent.getBooleanExtra("cheese", false)
        val contactInfoFormatted: String? = intent.getStringExtra("contactInfo")
        val delivery: Boolean? = intent.getBooleanExtra("delivery", false)
        val deliveryInstruction: String? = intent.getStringExtra("deliveryInstruction")

        var toppingText: String = ""

        if (topping != "Select a topping") {
            toppingText += "$topping \n"
        }

        toppingText += if (cheese == true) {
            "Extra cheese"
        } else {
            "No extra cheese"
        }

        var deliveryText = ""

        deliveryText += if (delivery == true) {
            "Delivery selected"
        } else {
            "No delivery selected, please pick up"
        }

        if (deliveryInstruction != "") {
            deliveryText += "\n Delivery Instructions: $deliveryInstruction"
        }

        pizzaSelectionText.text = pizza
        toppingSelectionText.text = toppingText
        contactDetailsText.text = contactInfoFormatted
        deliveryConfirmationText.text = deliveryText

        backButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("reset", true)

            startActivity(intent)
        }
    }
}