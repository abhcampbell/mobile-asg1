package com.example.assignment1_100703650

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.math.RoundingMode
import java.text.DecimalFormat


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val radioGroup: RadioGroup = findViewById(R.id.radioGroup)
        val pizzaSizeError: TextView = findViewById(R.id.pizzaSizeError)
        val toppingSpinner: Spinner = findViewById(R.id.spinner)
        val cheeseToggle: Switch = findViewById(R.id.cheeseToggle)
        val deliveryToggle: Switch = findViewById(R.id.deliveryToggle)
        val deliveryInstruction: EditText = findViewById(R.id.deliveryInstruction)
        val nameText: EditText = findViewById(R.id.name)
        val nameError: TextView = findViewById(R.id.nameError)
        val addressText: EditText = findViewById(R.id.address)
        val addressError: TextView = findViewById(R.id.addressError)
        val phoneText: EditText = findViewById(R.id.phone)
        val phoneError: TextView = findViewById(R.id.phoneError)
        val emailText: EditText = findViewById(R.id.email)
        val emailError: TextView = findViewById(R.id.emailError)
        val totalText: TextView = findViewById(R.id.totalText)
        val submitButton: Button = findViewById(R.id.submitButton)

        // Updates view based on if order is valid
        fun checkRequiredFields(): Boolean {
            var validOrder: Boolean = true
            var selectedRadioButtonId: Int = radioGroup.checkedRadioButtonId

            if (selectedRadioButtonId == -1) {
                // If no radio group is selected show error text view
                validOrder = false
                pizzaSizeError.visibility = View.VISIBLE
            }

            if (nameText.text.isEmpty()) {
                // If no name is input show error text view
                validOrder = false
                nameError.visibility = View.VISIBLE
            }

            if (addressText.text.isEmpty()) {
                // If no name is input show error text view
                validOrder = false
                addressError.visibility = View.VISIBLE
            }

            if (phoneText.text.isEmpty()) {
                // If no name is input show error text view
                validOrder = false
                phoneError.visibility = View.VISIBLE
            }

            if (emailText.text.isEmpty()) {
                // If no name is input show error text view
                validOrder = false
                emailError.visibility = View.VISIBLE
            }

            if (validOrder) {
                // Order is valid, any visible error labels will be made invisible
                pizzaSizeError.visibility = View.INVISIBLE
                nameError.visibility = View.INVISIBLE
                phoneError.visibility = View.INVISIBLE
                emailError.visibility = View.INVISIBLE
            }

            return validOrder
        }

        // Calculates the total based on what the user has input
        fun getTotal(): String {
            var total: Double = 0.0
            val selectedButtonIndex: Int = radioGroup.indexOfChild(findViewById(radioGroup.checkedRadioButtonId))
            val spinnerText: String = toppingSpinner.selectedItem.toString()
            val cheeseToggled: Boolean = cheeseToggle.isChecked
            val deliveryToggled: Boolean = deliveryToggle.isChecked

            when (selectedButtonIndex) {
                0 -> total += 5.50
                1 -> total += 7.99
                2 -> total += 9.50
                3 -> total += 11.38
            }

            when (spinnerText) {
                "Mushroom (\$5)" -> total += 5
                "Sun Dried Tomatoes (\$5)" -> total += 5
                "Chicken (\$7)" -> total += 7
                "Ground Beef (\$8)" -> total += 8
                "Shrimps (\$10)" -> total += 10
                "Pineapple (\$5)" -> total += 5
                "Steak (\$9)" -> total += 9
                "Avocado (\$5)" -> total += 5
                "Tuna ($5)" -> total += 5
                "Broccoli (\$8)" -> total += 8
            }

            if (cheeseToggled) {
                total += 5
            }

            if (deliveryToggled) {
                total += 5
            }

            val decimalFormat: DecimalFormat = DecimalFormat("#.##")
            decimalFormat.roundingMode = RoundingMode.DOWN

            return decimalFormat.format(total)
        }

        // Updates the total text
        fun updateTotal() {
            var total: String = "Total: " + getTotal()
            totalText.text = total
        }

        // Initialize spinner with list of toppings
        ArrayAdapter.createFromResource(
            this,
            R.array.toppings,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            toppingSpinner.adapter = adapter
        }

        // Set up submit button listener
        submitButton.setOnClickListener {
            val validOrder: Boolean = checkRequiredFields()

            if (!validOrder) {
                // Toast error
                Toast.makeText(applicationContext, "Please enter required fields", Toast.LENGTH_LONG).show()
            } else {
                // Valid order, will create an intent to go to the order confirmation activity
                val selectedRadioButton: RadioButton = findViewById(radioGroup.checkedRadioButtonId);
                val pizzaOptions = arrayOf(
                    selectedRadioButton.text.toString(),
                    toppingSpinner.selectedItem.toString(),
                    cheeseToggle.isChecked,
                    deliveryToggle.isChecked)

                // Sends order information to intent
                val intent = Intent(this, OrderInfoActivity::class.java)
                intent.putExtra("pizza", selectedRadioButton.text.toString())
                intent.putExtra("topping", toppingSpinner.selectedItem.toString())
                intent.putExtra("cheese", cheeseToggle.isChecked)
                intent.putExtra("delivery", deliveryToggle.isChecked)
                intent.putExtra("deliveryInstruction", deliveryInstruction.text.toString())
                intent.putExtra("contactInfo", "Name: " + nameText.text + "\n" + "Address: " + addressText.text + "\n" + "Phone: " + phoneText.text + "\n" + "Email: " + emailText.text + "\n")

                startActivity(intent)
            }
        }

        // Set up listeners to each element that affects the total
        radioGroup.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { _, selectedId ->
            when (selectedId) {
                selectedId -> updateTotal()
            }
        })

        toppingSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View, i: Int, l: Long) {
                updateTotal()
            }

            override fun onNothingSelected(adapterView: AdapterView<*>?) {
                updateTotal()
            }
        }

        cheeseToggle.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { _, _ ->
            updateTotal()
        })

        deliveryToggle.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { _, _ ->
            updateTotal()
        })
    }
}